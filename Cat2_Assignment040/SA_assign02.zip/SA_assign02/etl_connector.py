# etl_connector.py
import os
import time
import requests
from datetime import datetime
from pymongo import MongoClient, errors
from dotenv import load_dotenv

# Load local .env
load_dotenv()

MONGO_URI = os.getenv("MONGO_URI")
MONGO_DB = os.getenv("MONGO_DB", "ripe_connector")
RIPE_BASE_URL = os.getenv("RIPE_BASE_URL", "https://stat.ripe.net/data/")
RIPE_RESOURCE = os.getenv("RIPE_RESOURCE", "AS3333")

# Configuration
COLLECTION_NAME = "ripestat_raw"
REQUEST_TIMEOUT = 10  # seconds
RETRIES = 3
BACKOFF = 2  # seconds

def get_mongo_client():
    if not MONGO_URI:
        raise ValueError("MONGO_URI not found in environment (set it in .env)")
    return MongoClient(MONGO_URI)

def extract(resource=RIPE_RESOURCE, endpoint="as-overview"):
    url = f"{RIPE_BASE_URL.rstrip('/')}/{endpoint}/data.json"
    params = {"resource": resource}
    last_err = None
    for attempt in range(1, RETRIES + 1):
        try:
            resp = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.RequestException as e:
            last_err = e
            print(f"[extract] Attempt {attempt}/{RETRIES} failed: {e}")
            time.sleep(BACKOFF * attempt)
    print("[extract] All attempts failed.")
    raise last_err

def transform(raw_json):
    if not raw_json:
        return None
    doc = {
        "ingested_at": datetime.utcnow(),
        "query_resource": raw_json.get("query", {}),
        "status": raw_json.get("status"),
        "data": raw_json.get("data", {}),
        # optionally add metadata about transform
        "transform_notes": "Raw JSON stored under 'data'.",
    }
    return doc

def load(document):
    if not document:
        raise ValueError("No document to load.")
    try:
        client = get_mongo_client()
        db = client[MONGO_DB]
        collection = db[COLLECTION_NAME]
        result = collection.insert_one(document)
        print(f"[load] Inserted document id: {result.inserted_id}")
        return result.inserted_id
    except errors.PyMongoError as e:
        print(f"[load] MongoDB error: {e}")
        raise

def run_etl():
    print("Starting ETL job for RIPEstat...")
    raw = extract()
    if not raw:
        print("No data extracted. Exiting.")
        return
    doc = transform(raw)
    if not doc:
        print("Transform returned nothing. Exiting.")
        return
    load(doc)
    print("ETL job finished.")

if __name__ == "__main__":
    try:
        run_etl()
    except Exception as e:
        print(f"ETL failed: {e}")
